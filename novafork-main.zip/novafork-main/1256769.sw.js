self.opts = {
    zoneID: 1256769,
    swDomain: "push-sdk.com",
}
importScripts("https://push-sdk.com/f/sw.js")